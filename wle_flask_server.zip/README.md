
# WLE Flask Server (Vercel)

This is a minimal Flask server that serves Websim Live Events JSON at `/api/websim_events`.
It includes the **WLE Rift** live event and sets the start to **September 10, 2025 at 4:00 PM PT** (PDT, UTC-7), which is **2025-09-10T23:00:00Z**.

## Files
- `api/websim_events.py` — Flask app exporting `app`
- `requirements.txt` — Python dependencies
- `vercel.json` — Vercel runtime configuration

## Deploy on Vercel
1. Create a new Vercel project and import this folder (Git or drag-and-drop).
2. Ensure the Python runtime in `vercel.json` is respected (`python3.11`).
3. Deploy. Your endpoint will be available at:
   `https://<your-project>.vercel.app/api/websim_events`

## Response schema
```
{
  "version": "YYYY-MM-DD",
  "events": [
    {
      "id": "string",
      "start": "ISO-8601 UTC (Z)",
      "end": "ISO-8601 UTC (Z)",
      "runInPage": true|false,
      "code": "function(ctx){ ... }",
      "replayCode": "function(ctx){ ... } (optional)",
      "buildup": [ { "label": "...", "at": "...", "minutesBeforeStart": N, "code": "function(ctx){...}" } ]
    }
  ]
}
```

## Notes
- CORS: If you need custom CORS headers, you can add them by returning a `Response` and setting headers; most userscripts work fine without special CORS when hosted on Vercel.
- Timezone: The live window here is 30 minutes long (23:00–23:30 UTC).
